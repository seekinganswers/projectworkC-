﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPT230RPGClasses
{
    internal class Figther : Hero
    {
        public Figther() : base() 
        {
            this.pictureBox.Image = Properties.Resources.BlackBelt_Attack;
            this.Name = "BlueFigther";
            this.lblName.Text = "BlueFighter";
        }

        public Figther(string name, int HP, int Attack, Label lblHP, Label lblName, ProgressBar progressBar, PictureBox pictureBox): base (name, HP, Attack, lblHP, lblName, progressBar, pictureBox)
        {
            this.pictureBox.Image = Properties.Resources.BlackBelt_Attack;
        }

        public override int TakeDamage(int damage) // checks for damage of the hero
        {
   
            damage = base.TakeDamage(damage);

            if(this.HP == 0)
            {
                this.pictureBox.Image = Properties.Resources.BlackBelt_Dead;

            }
            else if ((double)this.HP /(double)this.MaxHP <= 0.60)
            {
                this.pictureBox.Image = Properties.Resources.BlackBelt_Wounded;
            }
            return damage;
        }

        public override int AttackDamage() // attacks method fo
        {

            return random.Next(this.Attack * 2, this.Attack * 2);
        }

    }
}
