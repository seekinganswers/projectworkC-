﻿namespace CPT230RPGClasses
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ptbxVillian = new PictureBox();
            ptbHero1 = new PictureBox();
            pgbHero1 = new ProgressBar();
            pgbVillian = new ProgressBar();
            pgbHero2 = new ProgressBar();
            ptbHero2 = new PictureBox();
            lblVillianPoints = new Label();
            lblHero1Points = new Label();
            linkLabel1 = new LinkLabel();
            lblHero2Points = new Label();
            lblVillianName = new Label();
            lblHero1Name = new Label();
            lblHero2Name = new Label();
            btnStart = new Button();
            txtOutput = new TextBox();
            btnReset = new Button();
            ptbMonster2 = new PictureBox();
            pgbMonster2 = new ProgressBar();
            lblVillianPoints2 = new Label();
            lblVillianName2 = new Label();
            ((System.ComponentModel.ISupportInitialize)ptbxVillian).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ptbHero1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ptbHero2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ptbMonster2).BeginInit();
            SuspendLayout();
            // 
            // ptbxVillian
            // 
            ptbxVillian.Image = Properties.Resources.Naocho;
            ptbxVillian.Location = new Point(12, 126);
            ptbxVillian.Name = "ptbxVillian";
            ptbxVillian.Size = new Size(125, 103);
            ptbxVillian.TabIndex = 0;
            ptbxVillian.TabStop = false;
            // 
            // ptbHero1
            // 
            ptbHero1.Image = Properties.Resources.BlackBelt_Attack;
            ptbHero1.Location = new Point(742, 126);
            ptbHero1.Name = "ptbHero1";
            ptbHero1.Size = new Size(116, 91);
            ptbHero1.SizeMode = PictureBoxSizeMode.Zoom;
            ptbHero1.TabIndex = 1;
            ptbHero1.TabStop = false;
            // 
            // pgbHero1
            // 
            pgbHero1.Location = new Point(742, 79);
            pgbHero1.Name = "pgbHero1";
            pgbHero1.Size = new Size(125, 29);
            pgbHero1.TabIndex = 2;
            // 
            // pgbVillian
            // 
            pgbVillian.Location = new Point(12, 79);
            pgbVillian.Name = "pgbVillian";
            pgbVillian.Size = new Size(125, 29);
            pgbVillian.TabIndex = 3;
            pgbVillian.Value = 100;
            // 
            // pgbHero2
            // 
            pgbHero2.Location = new Point(742, 329);
            pgbHero2.Name = "pgbHero2";
            pgbHero2.Size = new Size(125, 29);
            pgbHero2.TabIndex = 4;
            // 
            // ptbHero2
            // 
            ptbHero2.Image = Properties.Resources.WhiteMage_HEL2;
            ptbHero2.Location = new Point(742, 374);
            ptbHero2.Name = "ptbHero2";
            ptbHero2.Size = new Size(125, 129);
            ptbHero2.SizeMode = PictureBoxSizeMode.Zoom;
            ptbHero2.TabIndex = 5;
            ptbHero2.TabStop = false;
            // 
            // lblVillianPoints
            // 
            lblVillianPoints.AutoSize = true;
            lblVillianPoints.Location = new Point(12, 46);
            lblVillianPoints.Name = "lblVillianPoints";
            lblVillianPoints.Size = new Size(50, 20);
            lblVillianPoints.TabIndex = 6;
            lblVillianPoints.Text = "label1";
            // 
            // lblHero1Points
            // 
            lblHero1Points.AutoSize = true;
            lblHero1Points.Location = new Point(742, 46);
            lblHero1Points.Name = "lblHero1Points";
            lblHero1Points.Size = new Size(50, 20);
            lblHero1Points.TabIndex = 7;
            lblHero1Points.Text = "label2";
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Location = new Point(654, 197);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(0, 20);
            linkLabel1.TabIndex = 8;
            // 
            // lblHero2Points
            // 
            lblHero2Points.AutoSize = true;
            lblHero2Points.Location = new Point(742, 296);
            lblHero2Points.Name = "lblHero2Points";
            lblHero2Points.Size = new Size(50, 20);
            lblHero2Points.TabIndex = 9;
            lblHero2Points.Text = "label3";
            // 
            // lblVillianName
            // 
            lblVillianName.AutoSize = true;
            lblVillianName.Location = new Point(12, 21);
            lblVillianName.Name = "lblVillianName";
            lblVillianName.Size = new Size(50, 20);
            lblVillianName.TabIndex = 10;
            lblVillianName.Text = "label4";
            // 
            // lblHero1Name
            // 
            lblHero1Name.AutoSize = true;
            lblHero1Name.Location = new Point(742, 9);
            lblHero1Name.Name = "lblHero1Name";
            lblHero1Name.Size = new Size(50, 20);
            lblHero1Name.TabIndex = 11;
            lblHero1Name.Text = "label5";
            // 
            // lblHero2Name
            // 
            lblHero2Name.AutoSize = true;
            lblHero2Name.Location = new Point(742, 267);
            lblHero2Name.Name = "lblHero2Name";
            lblHero2Name.Size = new Size(50, 20);
            lblHero2Name.TabIndex = 12;
            lblHero2Name.Text = "label6";
            // 
            // btnStart
            // 
            btnStart.Location = new Point(550, 460);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(94, 29);
            btnStart.TabIndex = 13;
            btnStart.Text = "Start Game";
            btnStart.UseVisualStyleBackColor = true;
            btnStart.Click += btnStart_Click;
            // 
            // txtOutput
            // 
            txtOutput.Location = new Point(216, 92);
            txtOutput.Multiline = true;
            txtOutput.Name = "txtOutput";
            txtOutput.Size = new Size(438, 287);
            txtOutput.TabIndex = 14;
            // 
            // btnReset
            // 
            btnReset.Location = new Point(550, 495);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(94, 29);
            btnReset.TabIndex = 15;
            btnReset.Text = "Reset";
            btnReset.UseVisualStyleBackColor = true;
            btnReset.Click += btnReset_Click;
            // 
            // ptbMonster2
            // 
            ptbMonster2.Image = Properties.Resources.Ocho;
            ptbMonster2.Location = new Point(12, 386);
            ptbMonster2.Name = "ptbMonster2";
            ptbMonster2.Size = new Size(125, 103);
            ptbMonster2.TabIndex = 16;
            ptbMonster2.TabStop = false;
            // 
            // pgbMonster2
            // 
            pgbMonster2.Location = new Point(12, 350);
            pgbMonster2.Name = "pgbMonster2";
            pgbMonster2.Size = new Size(125, 29);
            pgbMonster2.TabIndex = 17;
            pgbMonster2.Value = 100;
            // 
            // lblVillianPoints2
            // 
            lblVillianPoints2.AutoSize = true;
            lblVillianPoints2.Location = new Point(12, 327);
            lblVillianPoints2.Name = "lblVillianPoints2";
            lblVillianPoints2.Size = new Size(50, 20);
            lblVillianPoints2.TabIndex = 18;
            lblVillianPoints2.Text = "label1";
            // 
            // lblVillianName2
            // 
            lblVillianName2.AutoSize = true;
            lblVillianName2.Location = new Point(12, 296);
            lblVillianName2.Name = "lblVillianName2";
            lblVillianName2.Size = new Size(50, 20);
            lblVillianName2.TabIndex = 19;
            lblVillianName2.Text = "label4";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(934, 530);
            Controls.Add(lblVillianName2);
            Controls.Add(lblVillianPoints2);
            Controls.Add(pgbMonster2);
            Controls.Add(ptbMonster2);
            Controls.Add(btnReset);
            Controls.Add(txtOutput);
            Controls.Add(btnStart);
            Controls.Add(lblHero2Name);
            Controls.Add(lblHero1Name);
            Controls.Add(lblVillianName);
            Controls.Add(lblHero2Points);
            Controls.Add(linkLabel1);
            Controls.Add(lblHero1Points);
            Controls.Add(lblVillianPoints);
            Controls.Add(ptbHero2);
            Controls.Add(pgbHero2);
            Controls.Add(pgbVillian);
            Controls.Add(pgbHero1);
            Controls.Add(ptbHero1);
            Controls.Add(ptbxVillian);
            Name = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)ptbxVillian).EndInit();
            ((System.ComponentModel.ISupportInitialize)ptbHero1).EndInit();
            ((System.ComponentModel.ISupportInitialize)ptbHero2).EndInit();
            ((System.ComponentModel.ISupportInitialize)ptbMonster2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox ptbxVillian;
        private PictureBox ptbHero1;
        private ProgressBar pgbHero1;
        private ProgressBar pgbVillian;
        private ProgressBar pgbHero2;
        private PictureBox ptbHero2;
        private Label lblVillianPoints;
        private Label lblHero1Points;
        private LinkLabel linkLabel1;
        private Label lblHero2Points;
        private Label lblVillianName;
        private Label lblHero1Name;
        private Label lblHero2Name;
        private Button btnStart;
        private TextBox txtOutput;
        private Button btnReset;
        private PictureBox ptbMonster2;
        private ProgressBar pgbMonster2;
        private Label lblVillianPoints2;
        private Label lblVillianName2;
    }
}