using System.Diagnostics.Eventing.Reader;

namespace CPT230RPGClasses
{
    /* Dorothy Hill
     * CPT 230
     * Fall 2023
     * RGP Game with added classes that will allow a player to play a
     * game between two heroes and  a villain. Once the heroes or 
     * villian is defeated the game will let the player know. It pulls
     * random numbers to defeat either opponent.
     */
    public partial class Form1 : Form
    {
        // variables to be used in game
        private Hero[] heroes;
        private Villian[] villians;
        private Queue<int> TurnQueue;
        private Random random;
        private bool gameOngoing = true;
       // private Queue<int> villianTurnQueue;
        private int VillianHP;
        public Form1()
        {
            InitializeComponent();
            random = new Random();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //setup for Villian

            villians = new Villian[2];
            villians[0] = new MonsterOne("RedMonster", 80, 10, lblVillianPoints, lblVillianName, pgbVillian, ptbxVillian);
            villians[1] = new MonsterTwo("GreenMonster", 80, 10, lblVillianPoints2, lblVillianName2, pgbMonster2, ptbMonster2);

            //setup for Villian
            heroes = new Hero[2];
            heroes[0] = new Figther("BlueFighter", 50, 20, lblHero1Points, lblHero1Name, pgbHero1, ptbHero1);
            heroes[1] = new Mage("WhiteMage", 75, 10, lblHero2Points, lblHero2Name, pgbHero2, ptbHero2);

            //turn queue for the heroes and villains
            TurnQueue = new Queue<int>();

            // set the turn queue
            SetupTurn();
        }

        // turn queue method for both heroes and villains
        private void SetupTurn()
        {

            for (int i = 0; i < heroes.Length; i++)
            {
                if (heroes[i].IsAlive())
                {
                    TurnQueue.Enqueue(i);
                }
            }

            for (int i = 0; i < villians.Length; i++)
            {
                if (villians[i].IsVillianAlive())
                {
                    TurnQueue.Enqueue(i + heroes.Length);
                }
            }
        }


        private void btnStart_Click(object sender, EventArgs e)
        {

            // track defeated heroes
          
            while (TurnQueue.Count > 0)
            {
                int currentTurn = TurnQueue.Dequeue();
                //int villianIndex = TurnQueue.Dequeue();              

                // get heroes to attack
                if (currentTurn < heroes.Length && currentTurn >= 0)
                { 
                    // Hero's turn
                    int damage = heroes[currentTurn].AttackDamage();

                    // hit villian
                    Random random = new Random();
                    int target = random.Next(0, villians.Length);

                    while (!villians[target].IsVillianAlive())
                    {
                        target = random.Next(0, villians.Length);
                    }

                    damage = villians[target].VillainTakeDamage(damage);

                    // Print out attack logs
                    txtOutput.Text = $"{heroes[currentTurn].GetName()} hit the {villians[target].GetVillianName()} for {damage}!\r\n{txtOutput.Text}";

                    WeWon();
                
                    // Check if the villain is defeated                   
                }
                else
                {
                    currentTurn = currentTurn - 2;
                    // get villian's attack damage
                    Random random = new Random();
                    int damage = villians[currentTurn].VillianAttackDamage();
                    int target = random.Next(0, heroes.Length);

                    //pick target
                    while (!heroes[target].IsAlive())
                    {
                        target = random.Next(0, heroes.Length);
                    }

                    // hit the hero
                    damage = heroes[target].TakeDamage(damage);

                    //print out what happened in the log
                    txtOutput.Text = $"{villians[currentTurn].GetVillianName()} hits {heroes[target].GetName()} for {damage}!\r\n{txtOutput.Text}";

                    if (!heroes[0].IsAlive() && !heroes[1].IsAlive())
                    {
                        //we lost
                        TurnQueue.Clear();
                        btnStart.Enabled = false;
                        MessageBox.Show("The Villians defeated the heroes!", "We lost!");
                    }
                }
            }
            SetupTurn();
        }


        private void VillianWins() // villian win method
        {
            // see if we lost
            if (!heroes[0].IsAlive() && heroes[1].IsAlive())
            {
                MessageBox.Show("We Lost to the Villian!", "We Lost!");
                btnStart.Enabled = false;
                TurnQueue.Clear();
            }
        }

        // the method for the heros when they win
        private void WeWon()
        {
                if (!villians[0].IsVillianAlive() && !villians[1].IsVillianAlive())
                {
                    MessageBox.Show("The heroes defeated the big villian!!", "The Heroes Won");
                    btnStart.Enabled = false;
                    TurnQueue.Clear();
                    return;  // Exit the loop as soon as one villain is defeated
                }
            //}
        }

        // Reset button to restart game
        private void btnReset_Click(object sender, EventArgs e)
        {
            //Enable start button 
            btnStart.Enabled = true;

            for (int i = 0; i < villians.Length; i++)
            {
                // Check if the villain is not null and initialize them
                if (villians[i] != null)
                {
                    // Set the initial HP values for villains
                    villians[i].SetInitialValues(80); // Replace with the initial HP value              
                }
            }

            for (int i = 0; i < heroes.Length; i++)
            {
                // Check if the hero is not null and initialize them
                if (heroes[i] != null)
                {
                    // Set the initial HP values for heroes
                    heroes[i].SetInitialValues(85); // Replace with the initial HP value
                }
            }

            // Clear the textbox
            txtOutput.Text = " ";

            // clear turn queues
            TurnQueue.Clear();
            TurnQueue.Clear();

            // Set the game state to ongoing
            gameOngoing = true;

            // causes the Setup turn to start a fresh queue
            SetupTurn();
        }
    }

}