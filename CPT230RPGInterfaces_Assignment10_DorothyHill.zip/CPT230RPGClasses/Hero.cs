﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPT230RPGClasses
{
    internal class Hero : ICombatable
    {
        //Data 
        protected string Name;
        protected int HP;
        protected int MaxHP;
        protected int Attack;

        protected Label lblHP;
        protected Label lblName;
        protected ProgressBar progressBar;
        protected PictureBox pictureBox;

        protected Random random;

        //Constructors
        public Hero()
        {
            this.Name = "Hero";
            this.HP = 100;
            this.MaxHP = HP;
            this.Attack = 10;
            this.lblHP = new Label();   
            this.lblName = new Label();
            this.progressBar = new ProgressBar();
            this.pictureBox = new PictureBox();
            this.random = new Random();
        }

        public Hero(string name, int HP, int Attack, Label lblHP, Label lblName, ProgressBar progressBar, PictureBox pictureBox)
        {
            // Setup for Name, HP, and Attack
            this.Name = name;
            this.HP = HP;
            this.MaxHP = HP;
            this.Attack = Attack;
            
            // Setup for label
            this.lblHP = lblHP;
            this.lblHP.Text = this.HP.ToString();           

            // Setup for Name
            this.lblName = lblName;
            this.lblName.Text = this.Name;
            
            // Setup for progress Bar
            this.progressBar = progressBar;
            this.progressBar.Maximum = this.HP;
            this.progressBar.Value = this.HP;
            
            // Setup for picture box
            this.pictureBox = pictureBox;
            
            // setup for random 
            this.random = new Random();
        }

        // Methods

        public string GetName()  // gets the name of the hero
        {
            return this.Name;
        }

        public bool IsAlive() // checks if the hero is alive
        {
            return this.HP > 0; 
        }

        public virtual int TakeDamage(int damage) // checks for damage of the hero
        {
            this.HP -= damage;
            if(this.HP < 0)
            {
                this.HP = 0;
            }
            this.lblHP.Text = this.HP.ToString();
            this.progressBar.Value = this.HP; 
            return damage;
        }

        public virtual int AttackDamage() // attacks method fo
        {
            return random.Next(this.Attack, this.Attack * 2);
        }
        public void SetInitialValues(int initialHP)
        {
            this.HP = initialHP;
            this.progressBar.Minimum = 0;  // Set the minimum value
            this.progressBar.Maximum = initialHP;  // Set the maximum value
            this.lblHP.Text = this.HP.ToString();
            this.progressBar.Value = this.HP;
        }

        public int VillianAttackDamage()
        {
            return random.Next(this.Attack, this.Attack * 2);
        }

        public int VillainTakeDamage(int damage)
        {
            this.HP -= damage;
            if (this.HP < 0)
            {
                this.HP = 0;
            }
            this.lblHP.Text = this.HP.ToString();
            this.progressBar.Value = this.HP;
            return damage;
        }
    }
}
