﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPT230RPGClasses
{
    // attackable interface
    public interface IAttackable
    {
        int VillainTakeDamage(int damage); // villians take damage
        int TakeDamage(int damage);  //heroes take damage
    }
}
