﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPT230RPGClasses
{
    //combined attack and take attack interface
    public interface ICombatable : ITargetables, IAttackable
    {

    }
}
