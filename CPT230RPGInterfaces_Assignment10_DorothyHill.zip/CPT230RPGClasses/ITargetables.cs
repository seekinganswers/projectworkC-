﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPT230RPGClasses
{
    // attack interface
    public interface ITargetables
    
    {
        int VillianAttackDamage(); //villians attack
        int AttackDamage(); //heroes attack
    }
}
