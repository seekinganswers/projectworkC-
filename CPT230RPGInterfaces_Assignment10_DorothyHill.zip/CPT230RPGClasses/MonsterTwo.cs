﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPT230RPGClasses
{
    internal class MonsterTwo : Villian
    {
        public MonsterTwo() : base()
        {
            this.pictureBox.Image = Properties.Resources.Naocho;
            this.Name = "GreenMonster";
            this.lblName.Text = "GreenMonster";
        }

        public MonsterTwo(string name, int HP, int Attack, Label lblHP, Label lblName, ProgressBar progressBar, PictureBox pictureBox) : base(name, HP, Attack, lblHP, lblName, progressBar, pictureBox)
        {
            this.pictureBox.Image = Properties.Resources.Naocho;
        }

        public override int VillainTakeDamage(int damage)
        {
            if (random.NextDouble() >= .6)
            {
                damage = 0;
            }
            else
            {
                damage = base.VillainTakeDamage(damage);

                if ((double)this.HP / (double)this.MaxHP <= 0.10)
                {
                    this.pictureBox.Image = Properties.Resources.Naocho;
                }
            }
            return damage;
        }

        public override int VillianAttackDamage()
        {
            return random.Next(this.Attack * 2, this.Attack * 3);
        }
    }
}
