﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPT230RPGClasses
{
    internal class Villian : ICombatable
    {
        //Data
        protected string Name;
        protected int HP;
        protected int MaxHP;
        protected int Attack;

        protected Label lblHP;
        protected Label lblName;
        protected ProgressBar progressBar;
        protected PictureBox pictureBox;

        protected Random random;

        // Constructors 
        public Villian()
        {
            this.Name = "Villian";
            this.HP = 1000;
            this.MaxHP = HP;
            this.Attack = 5;
            this.lblHP = new Label();
            this.lblName = new Label();
            this.progressBar = new ProgressBar();
            this.pictureBox = new PictureBox();
            this.random = new Random();
        }

        public Villian(string name, int hP, int attack, Label lblHP, Label lblName, ProgressBar progressBar, PictureBox pictureBox)
        {
            // Setup for Name, HP, and Attack
            this.Name = name;
            this.HP = hP;
            this.MaxHP = hP;
            this.Attack = attack;

            // Setup for label
            this.lblHP = lblHP;
            this.lblHP.Text = hP.ToString();

            // Setup for Name
            this.lblName = lblName;
            this.lblName.Text = name;

            //Setup Progress Bar
            this.progressBar = progressBar;
            this.progressBar.Maximum = this.HP;
            this.progressBar.Value = this.HP;

            // Setup for picture box
            this.pictureBox = pictureBox;

            // Setup for random
            this.random = new Random();
        }

        // Methods
        public string GetVillianName()
        {
            return this.Name;
        }

        public int VillianPoints()
        {
            return this.HP;
        }

        public bool IsVillianAlive()
        {
            return this.HP > 0;
        }

        public virtual int VillainTakeDamage(int damage)
        {
            this.HP -= damage;
            if (this.HP < 0)
            {
                this.HP = 0;
            }
            this.lblHP.Text = this.HP.ToString();
            this.progressBar.Value = this.HP;
            return damage;
        }

        public virtual int VillianAttackDamage()
        {
            return random.Next(this.Attack, this.Attack * 2);
        }

        public void SetInitialValues(int initialHP)
        {
            this.HP = initialHP;
            this.progressBar.Minimum = 0;  // Set the minimum value
            this.progressBar.Maximum = initialHP;  // Set the maximum value
            this.lblHP.Text = this.HP.ToString();
            this.progressBar.Value = this.HP;
        }

        public int AttackDamage()
        {
            return random.Next(this.Attack, this.Attack * 2);
        }

        public int TakeDamage(int damage)
        {
            this.HP -= damage;
            if (this.HP < 0)
            {
                this.HP = 0;
            }
            this.lblHP.Text = this.HP.ToString();
            this.progressBar.Value = this.HP;
            return damage;

        }
    }
}
