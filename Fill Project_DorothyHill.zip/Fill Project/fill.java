import java.util.*;
import java.util.concurrent.*;
/*
 *  Author:             Dorothy Hill
 *  Date:               4 April 2024
 *  Description:        Tell me what you think this program is doing.
 */

    /***********************************************************
     *  DON'T MODIFY ANYTHING FROM HERE UNTIL TOLD OTHERWISE.  *
     ***********************************************************/
/*
 * fill class with the main method
 */

class fill {
	/*
	 * declare variables
	 */

    private static int  array[] = new int[512 * 1024 * 1024];
	private static final Scanner console = new Scanner(System.in);

	/*
	 * static main method
	 */
    public static void main(String[] args)
    {
		/*
		 * declared variables
		 */
        int             valuesAdded;
        long            elapsed;
        RandomFill      randomFill;
		int				userInputThread;

		/*
		 * ask user for the number of thread to be used
		 */

		System.out.println("Enter the number of threads to be used: ");

		/*
		 * assigns userInputThread to the console.nextInt() variable
		 */
        userInputThread = console.nextInt();

		/*
		 * assigns randomFill to RandomFill for the userInputThread
		 */
        randomFill = new RandomFill(userInputThread);

		/*
		* assigns elapsed to nanoTime
		*/
        elapsed = System.nanoTime();

        /*
		 * assigns valuesAdded to randomFill.fillArray(array)
		*/
        valuesAdded = randomFill.fillArray(array);

        /*
		 * assigns elapsed to nanoTime
		*/
        elapsed = System.nanoTime() - elapsed;

        /*
		 * prints the variables valuesAdded and elapsed
		*/
        System.out.println(valuesAdded + " values added" +
                           " in " + elapsed + "ns");

    }
}

    /************************************
     *  MAKE YOUR MODIFICATIONS BELOW.  *
     ************************************/

 /*
  * creates a thread of the RandomFill class
  */

class RandomFill extends Thread {

	/*
	 * declared variables
	 */

	private int count;
	private static int[] worker;
	private int arrayLength;

	/*
	 * constructor for the above variables
	 */

	public RandomFill(int count)
	{
		this.count = count;
		this.worker = new int[count];
	}

	/*
	 * creates the fillArray method
	 */

	public int  fillArray(int array[])
    {
		// declared variables to be used to fill an array
        int     i;
        int     arrayLength;
        int     count;
        int     maxValue;
        java.util.Random        myRandom;

		/*
		 * if statement that assigns arrayLength to the array.length
		 * checks if the array.lenght is less than or equal zero
		 */

        if ((arrayLength = array.length) <= 0) {

			/*
			 * returns zero
			 */

            return(0);
        }

        /*
         * prints the array length
         */

        System.out.println(arrayLength + " items in array");

		/*
		 * declared variables to be used int he below array
		 * maxValue to arrayLength variable and
		 * myRandom to a predefined random methon in java
		 */

        maxValue = arrayLength;
        myRandom = new java.util.Random();

		/*
		 * starts count at zero
		 */

        count = 0;

        /*
         * for loop declares i as zero, i has to be less than the arraylenght
         * i is pre-incremented, and count is pre-incremented
         */

        for (i = 0; (i < arrayLength); ++i, ++count) {

			/*
			 * array variable uses i which is equal to the random number of the maxValue
			 */
            array[i] = myRandom.nextInt(maxValue);
        }

		 /*
		  * Multithreading logic starts here
		  */

        System.out.println("Worker: " + worker.length);

		 /*
		  * Calculate the number of elements each thread should process
		  */

		  int elementsPerThread = arrayLength / count;

		/*
		 * Create an array to store references to worker threads
		 */

        Worker[] threads = new Worker[count];

		/*
		 * print statement to print the worker's lenght
		 */

		System.out.println("Worker: " + worker.length);

		/*
		 * assigns arrayLength to the array.length
		 */

		arrayLength = array.length;

		 /*
		  * for loop that starts the worker threads
		 */

			for ( i = 0; i < count; i++) {
				/*
				 * declares the startIndex and multiply it by i and the elementsPerThread
				 */
				int startIndex = i * elementsPerThread;

				/*
				 * creates the endIndex variable and checks if the thread is the last one
				 */
				int endIndex = (i == count - 1) ? arrayLength : (i + 1) * elementsPerThread;

				/*
				 * creates a new worker array with the above variables
				 */
				threads[i] = new Worker(array, startIndex, endIndex);

				/*
				 * Start the thread
				 */
				threads[i].start();
			}

				/*
				 * Try Catch statement that waits for all worker threads to finish
				 */

				try {

					/*
					 * loops through the worker wait for each thread to finish
					 */
					for (Worker thread : threads) {
						thread.join();
					}
					/*
					 * catch statement to through an interruption
					 */
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}

				/*
				 * Sum counts from each thread
				 */
				int totalValuesAdded = 0; // variable for the sum

				/*
				 * loop that iterates through each worker
				 */

				for (int c : worker) {
					totalValuesAdded += count; //
				}
				/*
				 * returns the sum for each thread
				 */
				return totalValuesAdded;
			}

		/*
		 * creates the Worker Thread class
		 */

		static class Worker extends Thread {

			/*
			 * declared variables
			 */

			private int[] array; // creates an array
			private int startIndex; // starts index variable
			private int endIndex; // ends index variable

			/*
			 * constructor for the worker arrary from the
			 * declared variables in the Worker Thread
			 */

			public Worker(int[] array, int startIndex, int endIndex) {
				this.array = array;
				this.startIndex = startIndex;
				this.endIndex = endIndex;
			}

			/*
			 * run method to run the thread array
			 */

			public void run() {

				/*
				 * for loop that sets i to startIndex
				 * i has to be less than the endIndex
				 * i is incremented by 1
				 */
				for (int i = startIndex; i < endIndex; i++) {

					/*
					 * Increment each element in the assigned chunk
					 */
					array[i]++;

					/*
					 * Increment worker array as i
					 */
					worker[i]++;
				}
			}
		}
}