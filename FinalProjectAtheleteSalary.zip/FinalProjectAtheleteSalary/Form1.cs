﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class Form1 : Form
    {
        private List<Professional> professionalList;
        private double athleteSalary;
        private double totalAmountPaid = 0;
        private double remainingAmount;
       
        
        public Form1()
        {
            InitializeComponent();
            professionalList = new List<Professional>();
    }

        private void button3_Click(object sender, EventArgs e)
        {


            RefreshDataGridView();

        }

        private bool ValidateSalaryInput(string inputSalary, out double salary)
        {
            string trimInput = inputSalary.Trim();
            if (!double.TryParse(trimInput, out salary) || salary <= 0)
            {
                MessageBox.Show("Enter a valid salary for the athlete.");
                salary = 0; 
                return false;
            }

            else
            {
                label4.Text = "The Athlete's Salary is: " + salary.ToString("c");
                return true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string inputSalary = groupBox1.Controls["AthleteSalaryTextBox"].Text;
            double salary;

            bool salaryIsValid = ValidateSalaryInput(inputSalary, out salary);

            if (salaryIsValid)
            {
                athleteSalary = salary;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
           /* double athleteSalary;
            double.TryParse(AthleteSalaryTextBox.Text, out athleteSalary);
            double remainingAmount;
            double.TryParse(textBox2.Text, out remainingAmount);

            double subAmount;
            double.TryParse(textBox3.Text, out subAmount);

            if (!ValidateSalaryInput(groupBox1.Controls["AthleteSalaryTextBox"].Text, out athleteSalary))
            {
                return;
            }*/

            if(athleteSalary <= 0)
            {
                MessageBox.Show("Enter a salary");
                return;
            }

            string jobs = groupBox2.Controls.OfType<RadioButton>().FirstOrDefault(r => r.Checked)?.Text;       
                        
            string nameOfProfessional = groupBox2.Controls["textBox1"].Text.Trim();
            groupBox2.Controls.Add(radioButton1);
            groupBox2.Controls.Add(radioButton2);
            groupBox2.Controls.Add(radioButton3);
            groupBox2.Controls.Add(radioButton4);

            if (string.IsNullOrEmpty(nameOfProfessional))
            {
                MessageBox.Show("Enter a valid name.");
                return;
            }

            if(label7.Text != null)
            {
                label7.Text = "";
            }
            
            double paymentsPercentage = 0.0;

            if(jobs == "Lawyer")
            {
                paymentsPercentage = 0.10;
            }
            else if (jobs == "Agent")
            {
                paymentsPercentage = 0.07;
            }
            else if (jobs == "Personal Assistant")
            {
                paymentsPercentage = 0.03;
            }
            else if (jobs == "Trainer")
            {
                paymentsPercentage = 0.05;
            }

            Professional professionalJobs = new Professional(nameOfProfessional, jobs);

            if (textBox2.Text == string.Empty) 
            {
                professionalJobs.Payment = paymentsPercentage * athleteSalary;
                remainingAmount = athleteSalary - professionalJobs.Payment;
                totalAmountPaid += professionalJobs.Payment;
            }
            
            else
            {
                professionalJobs.Payment = paymentsPercentage * remainingAmount; // Use remaining amount
                remainingAmount -= professionalJobs.Payment; // Deduct the payment
                totalAmountPaid += professionalJobs.Payment;
            }

           // subAmount = athleteSalary - professionalJobs.Payment;

            professionalList.Add(professionalJobs);

            textBox2.Text = professionalJobs.Payment.ToString("C"); // Total paid
            textBox3.Text = remainingAmount.ToString("C");

            groupBox2.Controls["textBox1"].Text = "";

                    string professionalInfo = "Name: " + nameOfProfessional + "\n" + "\nOccupation: " + jobs + "\n" + "\nAthlete Salary: " + athleteSalary;

                    label7.Text = professionalInfo;
        }

      
        private void RefreshDataGridView()
        {
            NewAtheleSalaryDataGridView.DataSource = null;
            NewAtheleSalaryDataGridView.DataSource = professionalList;
        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            AthleteSalaryTextBox.Text = "";
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            label4.Text = "";
            label7.Text = "";
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;
        }
    }
}
