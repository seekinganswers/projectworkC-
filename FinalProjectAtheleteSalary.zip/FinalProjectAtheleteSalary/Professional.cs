﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject
{
    public class Professional
    {
        private string _professionalName;
        private string _occupation;
        private double _payment;


        public string ProfessionalName { get; set; }
        
        public string Occupation { get; set; }
        
        public double Payment { get; set; }


        public Professional(string name, string occupation)
        {
            ProfessionalName = name;
            Occupation = occupation;
            Payment = 0.0;
        }      
    }   
}
