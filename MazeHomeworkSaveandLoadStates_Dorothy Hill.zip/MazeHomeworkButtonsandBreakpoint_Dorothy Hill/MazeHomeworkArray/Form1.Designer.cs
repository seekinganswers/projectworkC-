﻿namespace MazeHomeworkArray
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtOutput = new TextBox();
            btnNorth = new Button();
            btnEast = new Button();
            btnSouth = new Button();
            btnWest = new Button();
            btnHint = new Button();
            btnRest = new Button();
            txtX = new TextBox();
            txtY = new TextBox();
            btnAction = new Button();
            txtStartTime = new TextBox();
            txtSTime = new TextBox();
            cboBox = new ComboBox();
            rdbWest = new RadioButton();
            rdbNorth = new RadioButton();
            rdbEast = new RadioButton();
            rdbSouth = new RadioButton();
            label1 = new Label();
            btnSave = new Button();
            btnLoad = new Button();
            SuspendLayout();
            // 
            // txtOutput
            // 
            txtOutput.Location = new Point(202, 38);
            txtOutput.Margin = new Padding(4);
            txtOutput.Multiline = true;
            txtOutput.Name = "txtOutput";
            txtOutput.Size = new Size(433, 206);
            txtOutput.TabIndex = 0;
            // 
            // btnNorth
            // 
            btnNorth.Location = new Point(328, 340);
            btnNorth.Margin = new Padding(4);
            btnNorth.Name = "btnNorth";
            btnNorth.Size = new Size(118, 35);
            btnNorth.TabIndex = 1;
            btnNorth.Text = "North";
            btnNorth.UseVisualStyleBackColor = true;
            btnNorth.Click += btnNorth_Click;
            // 
            // btnEast
            // 
            btnEast.Location = new Point(480, 405);
            btnEast.Margin = new Padding(4);
            btnEast.Name = "btnEast";
            btnEast.Size = new Size(118, 35);
            btnEast.TabIndex = 2;
            btnEast.Text = "East";
            btnEast.UseVisualStyleBackColor = true;
            btnEast.Click += btnEast_Click;
            // 
            // btnSouth
            // 
            btnSouth.Location = new Point(328, 458);
            btnSouth.Margin = new Padding(4);
            btnSouth.Name = "btnSouth";
            btnSouth.Size = new Size(118, 35);
            btnSouth.TabIndex = 3;
            btnSouth.Text = "South";
            btnSouth.UseVisualStyleBackColor = true;
            btnSouth.Click += btnSouth_Click;
            // 
            // btnWest
            // 
            btnWest.Location = new Point(177, 405);
            btnWest.Margin = new Padding(4);
            btnWest.Name = "btnWest";
            btnWest.Size = new Size(118, 35);
            btnWest.TabIndex = 4;
            btnWest.Text = "West";
            btnWest.UseVisualStyleBackColor = true;
            btnWest.Click += btnWest_Click;
            // 
            // btnHint
            // 
            btnHint.Location = new Point(794, 398);
            btnHint.Margin = new Padding(4);
            btnHint.Name = "btnHint";
            btnHint.Size = new Size(118, 35);
            btnHint.TabIndex = 5;
            btnHint.Text = "Hint";
            btnHint.UseVisualStyleBackColor = true;
            btnHint.Click += btnHint_Click;
            // 
            // btnRest
            // 
            btnRest.Location = new Point(794, 462);
            btnRest.Margin = new Padding(4);
            btnRest.Name = "btnRest";
            btnRest.Size = new Size(118, 35);
            btnRest.TabIndex = 6;
            btnRest.Text = "Rest";
            btnRest.UseVisualStyleBackColor = true;
            btnRest.Click += btnRest_Click;
            // 
            // txtX
            // 
            txtX.Location = new Point(794, 55);
            txtX.Margin = new Padding(4);
            txtX.Name = "txtX";
            txtX.Size = new Size(46, 32);
            txtX.TabIndex = 7;
            // 
            // txtY
            // 
            txtY.Location = new Point(874, 55);
            txtY.Margin = new Padding(4);
            txtY.Name = "txtY";
            txtY.Size = new Size(46, 32);
            txtY.TabIndex = 8;
            // 
            // btnAction
            // 
            btnAction.Location = new Point(328, 405);
            btnAction.Margin = new Padding(4);
            btnAction.Name = "btnAction";
            btnAction.Size = new Size(118, 35);
            btnAction.TabIndex = 9;
            btnAction.Text = "Action";
            btnAction.UseVisualStyleBackColor = true;
            btnAction.Click += btnAction_Click;
            // 
            // txtStartTime
            // 
            txtStartTime.Location = new Point(833, 132);
            txtStartTime.Name = "txtStartTime";
            txtStartTime.ReadOnly = true;
            txtStartTime.Size = new Size(101, 32);
            txtStartTime.TabIndex = 11;
            txtStartTime.Text = "Timer";
            txtStartTime.TextChanged += txtStartTime_TextChanged;
            // 
            // txtSTime
            // 
            txtSTime.Location = new Point(732, 170);
            txtSTime.Name = "txtSTime";
            txtSTime.Size = new Size(212, 32);
            txtSTime.TabIndex = 12;
            // 
            // cboBox
            // 
            cboBox.FormattingEnabled = true;
            cboBox.Location = new Point(769, 327);
            cboBox.Name = "cboBox";
            cboBox.Size = new Size(151, 32);
            cboBox.TabIndex = 13;
            // 
            // rdbWest
            // 
            rdbWest.AutoSize = true;
            rdbWest.Location = new Point(224, 447);
            rdbWest.Name = "rdbWest";
            rdbWest.Size = new Size(17, 16);
            rdbWest.TabIndex = 14;
            rdbWest.UseVisualStyleBackColor = true;
            // 
            // rdbNorth
            // 
            rdbNorth.AutoSize = true;
            rdbNorth.BackColor = SystemColors.Control;
            rdbNorth.Location = new Point(378, 382);
            rdbNorth.Name = "rdbNorth";
            rdbNorth.Size = new Size(17, 16);
            rdbNorth.TabIndex = 15;
            rdbNorth.UseVisualStyleBackColor = false;
            rdbNorth.CheckedChanged += rdbNorth_CheckedChanged;
            // 
            // rdbEast
            // 
            rdbEast.AutoSize = true;
            rdbEast.BackColor = SystemColors.Control;
            rdbEast.Location = new Point(530, 447);
            rdbEast.Name = "rdbEast";
            rdbEast.Size = new Size(17, 16);
            rdbEast.TabIndex = 16;
            rdbEast.UseVisualStyleBackColor = false;
            // 
            // rdbSouth
            // 
            rdbSouth.AutoSize = true;
            rdbSouth.Location = new Point(378, 500);
            rdbSouth.Name = "rdbSouth";
            rdbSouth.Size = new Size(17, 16);
            rdbSouth.TabIndex = 17;
            rdbSouth.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(718, 291);
            label1.Name = "label1";
            label1.Size = new Size(270, 24);
            label1.TabIndex = 18;
            label1.Text = "Choose the correct exit answer";
            // 
            // btnSave
            // 
            btnSave.Location = new Point(12, 149);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(129, 29);
            btnSave.TabIndex = 19;
            btnSave.Text = "Save Game";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnLoad
            // 
            btnLoad.Location = new Point(12, 197);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(129, 29);
            btnLoad.TabIndex = 20;
            btnLoad.Text = "Load Game";
            btnLoad.UseVisualStyleBackColor = true;
            btnLoad.Click += btnLoad_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 24F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1000, 540);
            Controls.Add(btnLoad);
            Controls.Add(btnSave);
            Controls.Add(label1);
            Controls.Add(rdbSouth);
            Controls.Add(rdbEast);
            Controls.Add(rdbNorth);
            Controls.Add(rdbWest);
            Controls.Add(cboBox);
            Controls.Add(txtSTime);
            Controls.Add(txtStartTime);
            Controls.Add(btnAction);
            Controls.Add(txtY);
            Controls.Add(txtX);
            Controls.Add(btnRest);
            Controls.Add(btnHint);
            Controls.Add(btnWest);
            Controls.Add(btnSouth);
            Controls.Add(btnEast);
            Controls.Add(btnNorth);
            Controls.Add(txtOutput);
            Font = new Font("Calibri", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Margin = new Padding(4);
            Name = "Form1";
            Text = "North, South, East, West Maze";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtOutput;
        private Button btnNorth;
        private Button btnEast;
        private Button btnSouth;
        private Button btnWest;
        private Button btnHint;
        private Button btnRest;
        private TextBox txtX;
        private TextBox txtY;
        private Button btnAction;
        private TextBox txtStartTime;
        private TextBox txtSTime;
        private ComboBox cboBox;
        private RadioButton rdbWest;
        private RadioButton rdbNorth;
        private RadioButton rdbEast;
        private RadioButton rdbSouth;
        private Label label1;
        private Button btnSave;
        private Button btnLoad;
    }
}