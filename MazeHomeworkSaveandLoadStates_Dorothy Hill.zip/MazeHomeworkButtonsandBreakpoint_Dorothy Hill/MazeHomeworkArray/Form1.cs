using System;
using System.Diagnostics.Contracts;
using System.IO;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace MazeHomeworkArray
{
    /*
     * Dorothy Hill
     * CPT 230 W01
     * 11/13/2023
     * Fall 2023
     * Homework Maze With DateTime Add 
     * 
     * This program uses an array to allow the users to navigate through the maze.
     * The user will be able to use the action button to determine if they 
     * can exit the game. A DateTime feature has been added so the user can 
     * view the time it took to get through the maze.
     * 
     * Added new feature is the save and load states.
     */

    public partial class Form1 : Form
    {
        private string startMessage; // start message string
        private string endMessage; // second part of the start message string
        DateTime startTime; // start Datetime
        DateTime endTime; // end Datetime
        private string dir;  //creates a directory
        private string binaryFile; //creates a binary file in the C drive
        public Form1()
        {
            InitializeComponent();

            // x and y are initialized to use in the array
            x = 0;
            y = 0;

            // start message and end message strings
            string startMessage = "You are in a room with an exit to the North, South, East, and West.";
            string endMessage = "Click the action button in a room to see if it's the exit.";
            txtOutput.Text += $"{startMessage}, {endMessage}";  // combined start and end message strings in output

            // directoy variable 
            dir = @"C:\C#\DorothyHill";
            // binary file variable 
            binaryFile = @"Binary.bin"; 
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // starter message to start the game
            startTime = DateTime.Now;  //start time initalized with current time
            txtSTime.Text = startTime.ToString();  //output the start time 
            endTime = DateTime.Now; // end time initalized with current time
            string[] strings = { "Key", "House", "Van" }; //initalized combobox list

            // foreach loop to add the variable strings to the combo box
            foreach (string s in strings)
            {
                cboBox.Items.Add(s); // add string to combo box
            }
            cboBox.SelectedIndex = 1; // starts the combo box off at index 1


        }
        private int x = 0; // Initialize the starting x-coordinate
        private int y = 0; // Initialize the starting y-coordinate
        private string k = "key"; //Initialize the the k value for key used in the action button


        // 2D array of the coordiates used in the methods
        string[] North = { "0,0", "0,1", "0,2", "0,3" };
        string[] South = { "0,0", "0,-1", "0,-2", "0,-3" };
        string[] East = { "0,0", "1,0", "2,0", "3,0" };
        string[] West = { "0,0", "-1,0", "-2,0", "-3,0" };

        // 2D array for text associated with the array above to be used in the MoveMovement method
        string[] NorthRooms = {"You are in a room with an exit to the North, South, East and West.", "You are in a room with an exit to the North and South.",
                                "You are in a room with an exit to the North and South.", "You are in a room with an exit to the South."};
        string[] SouthRooms = {"You are in a room with an exit to the North, South, East and West.", "You are in a room with an exit to the South and North.",
                                "You are in a room to the South and North.", "You are in a room with an exit to the North."};
        string[] EastRooms = {"You are in a room with an exit to the North, South, East and West.", "You are in a room with an exit to the East and West.",
                                "You are in a room with an exit to the East and West.", "You are in a room with an exit to the West."};
        string[] WestRooms = {"You are in a room with an exit to the North, South, East and West.", "You are in a room with an exit to the West and East.",
                                "You are in a room with an exit to the West and East.", "You are in a room with an exit to the East."};


        // Method ot coordinate the name associated with the array to be used in the MoveMovement
        private enum Direction
        {
            North,
            South,
            East,
            West
        }

        private void SaveGameState()
        {
            try
            {
                //creates a director if one doesn't exists
                if (!Directory.Exists(dir))
                {
                    Directory.CreateDirectory(dir);
                }

                // variables declared to be saved in the game
                int x = Convert.ToInt32(txtX.Text);
                int y = Convert.ToInt32(txtY.Text);
                string roominfo = txtOutput.Text;
                string selectedItem = cboBox.SelectedItem != null ? cboBox.SelectedItem.ToString() : string.Empty;

                using BinaryWriter binaryWriter = new BinaryWriter(new FileStream(dir + binaryFile, FileMode.Append, FileAccess.Write));
                //writes data on one line in the text file and application
                {
                    binaryWriter.Write(x); // saves x coordinates
                    binaryWriter.Write(y);// saves y coordinates
                    binaryWriter.Write(roominfo); //// saves output message 
                    // Save the selected item from ComboBox
                    binaryWriter.Write(selectedItem);

                }
            }
            catch (UnauthorizedAccessException)
            {
                MessageBox.Show("You do not have access to this file.", "Access Denied");
            }
            catch (IOException ex)
            {
                MessageBox.Show("There was an error saving the game.", "Error");
            }
        }

        // creates a load/read from a binary file for the x and y coordinates

        private void LoadGameState()
        {
            try
            {
                //creates a director if one doesn't exists
                if (!Directory.Exists(dir))
                {
                    Directory.CreateDirectory(dir);
                }
                if (File.Exists(dir + binaryFile))
                {
                    using BinaryReader binaryReader = new BinaryReader(new FileStream(dir + binaryFile, FileMode.OpenOrCreate, FileAccess.Read));

                    while (binaryReader.PeekChar() != -1) // writes the last saved game state
                    {
                        // variables declared to be written in the game
                        int x = binaryReader.ReadInt32();
                        int y = binaryReader.ReadInt32();
                        string roominfo = binaryReader.ReadString();
                        string selectedItem = binaryReader.ReadString();

                        // appear when the game loads to show the last saved state
                        txtX.Text = x.ToString();
                        txtY.Text = y.ToString();
                        txtOutput.Text = roominfo;


                        // select the item in the combo box if one was saved in the game
                        if(!string.IsNullOrEmpty(selectedItem))
                        {
                            cboBox.SelectedItem = selectedItem;
                        }
                    }
                }
            }
            catch (UnauthorizedAccessException)
            {
                MessageBox.Show("You do not have access to this file.", "Access Denied");
            }
            catch (Exception ex)
            {
                MessageBox.Show("The file doesn't exist.");
            }
        }

        // Method to allow the click buttons to move using the above arrays and switch statements
        private void MoveMovement(Direction newDirection)
        {
            switch (newDirection)

            {
                // Switch North used in the north button
                case Direction.North:
                    // assigns a string to the position in the array and move the array to the next position
                    string newMove = x.ToString() + "," + (y + 1).ToString();

                    // uses an array to search the North array position
                    int index = Array.BinarySearch(North, newMove);

                    // Check if you're in the North room and allow moving to the Nouth
                    if (index >= 0)
                    {
                        txtOutput.Text = " "; // clears the output textbox
                        y = 1 + y;
                        txtOutput.Text += NorthRooms[index];  // Lets the player know which room they are in

                        // Update x and y coordinates
                        txtX.Text = x.ToString();
                        txtY.Text = y.ToString();
                        SaveGameState();
                    }
                    else if (y == -3) // Move from the South room furthest point 
                    {
                        txtOutput.Text = " "; // clears the output textbox
                        y = y + 1;
                        txtOutput.Text = $"You are in a room with an exit to the North.";

                        // Update x and y coordinates
                        txtX.Text = x.ToString();
                        txtY.Text = y.ToString();
                        SaveGameState();
                    }
                    else if (y == -2 || y == -1) // Move from the other two points in the south room 
                    {
                        txtOutput.Text = " "; // clears the output textbox
                        y = y + 1;
                        txtOutput.Text = $"You are in a room with an exit to the North and South.";

                        // Update x and y coordinates
                        txtX.Text = x.ToString();
                        txtY.Text = y.ToString();
                        SaveGameState();
                    }
                    break;

                // Switch Southth used in the south button
                case Direction.South:

                    // assigns a string to the position in the array and move the array to the next position
                    string newMoveSouth = x.ToString() + "," + (y - 1).ToString();

                    // uses an array to search the South array position
                    int indexSouth = Array.BinarySearch(South, newMoveSouth);

                    // Check if you're in the South room and allow moving to the South
                    if (indexSouth >= 0)
                    {
                        txtOutput.Text = " "; // clears the output textbox
                        y = y - 1;
                        txtOutput.Text += SouthRooms[indexSouth]; // Lets the player know which room they are in

                        // Update x and y coordinates
                        txtX.Text = x.ToString();
                        txtY.Text = y.ToString();
                        SaveGameState();
                    }

                    else if (y == 3) // Move from the North room furthest point
                    {
                        txtOutput.Text = " "; // clears the output textbox
                        y = y - 1;
                        txtOutput.Text += $"You are in a room with an exit to the South.";

                        // Update x and y coordinates
                        txtX.Text = x.ToString();
                        txtY.Text = y.ToString();
                        SaveGameState();
                    }
                    else if (y == 2 || y == 1) // Move from the other two points in the north room 
                    {
                        txtOutput.Text = " "; // clears the output textbox
                        y = y - 1;
                        txtOutput.Text = $"You are in a room with an exit to the South and North.";

                        // Update x and y coordinates
                        txtX.Text = x.ToString();
                        txtY.Text = y.ToString();
                        SaveGameState();
                    }
                    break;

                // Switch East used in the east button
                case Direction.East:
                    // assigns a string to the position in the array and move the array to the next position
                    string newMoveEast = (x + 1).ToString() + "," + (y).ToString();

                    // uses an array to search the East array position
                    int indexEast = Array.BinarySearch(East, newMoveEast);
                    if (indexEast >= 0)
                    {
                        txtOutput.Text = " "; // clears the output textbox
                        x = 1 + x;
                        txtOutput.Text += EastRooms[indexEast];  // Lets the player know which room they are in

                        // Update x and y coordinates
                        txtX.Text = x.ToString();
                        txtY.Text = y.ToString();
                        SaveGameState();
                    }
                    else if (x == -3) // Move from the West room furthest point
                    {
                        txtOutput.Text = " "; // clears the output textbox
                        x = x + 1;
                        txtOutput.Text += $"You are in a room with an exit to the East.";

                        // Update x and y coordinates
                        txtX.Text = x.ToString();
                        txtY.Text = y.ToString();
                        SaveGameState();
                    }
                    else if (x == -2 || x == -1)  // Move from the other two points in the west room 
                    {
                        txtOutput.Text = " "; // clears the output textbox
                        x = x + 1;
                        txtOutput.Text += $"You are in a room with an exit to the North and West.";

                        // Update x and y coordinates
                        txtX.Text = x.ToString();
                        txtY.Text = y.ToString();
                        SaveGameState();
                    }


                    break;

                // Switch West used in the west button
                case Direction.West:

                    // assigns a string to the position in the array and move the array to the next position
                    string newMoveWest = (x - 1).ToString() + "," + (y).ToString();

                    // uses an array to search the West array position
                    int indexWest = Array.BinarySearch(West, newMoveWest);

                    // Check if you're in the West room and allow moving to the West
                    if (indexWest >= 0)
                    {
                        txtOutput.Text = " ";  // clears the output textbox
                        x = x - 1;
                        txtOutput.Text += WestRooms[indexWest]; // Lets the player know which room they are in

                        // Update x and y coordinates
                        txtX.Text = x.ToString();
                        txtY.Text = y.ToString();
                        SaveGameState();
                    }
                    else if (x == 3) // Move from the East room furthest point
                    {
                        txtOutput.Text = " ";  // clears the output textbox
                        x = x - 1;
                        txtOutput.Text += $"You are in a room with an exit to the West.";

                        // Update x and y coordinates
                        txtX.Text = x.ToString();
                        txtY.Text = y.ToString();
                        SaveGameState();
                    }
                    else if (x == 2 || x == 1)  // Move from the other two points in the east room 
                    {
                        txtOutput.Text = " ";  // clears the output textbox
                        x = x - 1;
                        txtOutput.Text += $"You are in a room with an exit to the West and East.";

                        // Update x and y coordinates
                        txtX.Text = x.ToString();
                        txtY.Text = y.ToString();
                        SaveGameState();
                    }

                    break;
            }
        }
        // creates a save/write game in a binary file for the x and y coordinates
        
        private void ChangeButtonColor() // changes the color of the winner room
        {
            Random random = new Random();
            Color randomColor = Color.FromArgb(random.Next(256), random.Next(256), random.Next(256));
            btnNorth.BackColor = randomColor;
            txtX.BackColor = randomColor;
            txtY.BackColor = randomColor;
        }

        private void DisableButtons() // disable click buttons
        {
            btnNorth.Enabled = false;
            btnSouth.Enabled = false;
            btnWest.Enabled = false;
            btnEast.Enabled = false;
            btnAction.Enabled = false;

        }


        private void btnAction_Click(object sender, EventArgs e)
        {
            // allows the user to exit the game when they get the 
            // correct coordinates 


            // x and y variables in the textbox to the right 
            int x = Convert.ToInt32(txtX.Text);
            int y = Convert.ToInt32(txtY.Text);



            if (x == 0 && y == 1)
            {
                MessageBox.Show($"You have made it out of the room!", "You win!"); // message box for winning
                endTime = DateTime.Now;  // end time variable initalized to the curre time 
                TimeSpan timeSpan = endTime - startTime; // timeSpan equation to get the difference between start and end time
                txtSTime.Text = ""; // clears the textbox of the start time
                txtSTime.Text += Math.Round(timeSpan.TotalSeconds).ToString(); //output the time it took to complete the game


                // changes the room color of the winning room 
                ChangeButtonColor();
                Task.Delay(500);

                // disables all rooms once the game has been won
                DisableButtons();

                // Dialogue box to ask user to contiune the game 
                DialogResult dialogResult = MessageBox.Show(" Would you like to start over?", "Reset Game", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                SaveGameState();
                if (dialogResult == DialogResult.Yes)
                {
                    ResetGame();
                }
                else
                {
                    this.Close();
                }
            }

            // lets the user know they are close to the winning room
            else if (x == 0 && y == 2)
            {
                MessageBox.Show($"You are almost there!");
                btnAction.Enabled = false;
                SaveGameState();
            }

            // another exit for the user to finish the game
            else if (x == 2 && y == 0 && cboBox.SelectedItem == "Key") // compared the coordinates and key value
            {

                txtOutput.Text = "You exited the game using a short cut.";
                MessageBox.Show($"You have made it out of the room!", $"You win!");

                endTime = DateTime.Now;  // end time variable initalized to the curre time 
                TimeSpan timeSpan = endTime - startTime; // timeSpan equation to get the difference between start and end time
                txtSTime.Text = ""; // clears the textbox of the start time
                txtSTime.Text += Math.Round(timeSpan.TotalSeconds).ToString(); //output the time it took to complete the game

                // changes the room color of the winning room 
                ChangeButtonColor();
                Task.Delay(500);

                // disables all rooms once the game has been won
                DisableButtons();

                DialogResult dialogResult = MessageBox.Show(" Would you like to start over?", "Reset Game", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                SaveGameState();
                if (dialogResult == DialogResult.Yes)
                {
                    ResetGame();
                }
                else
                {
                    this.Close();
                }
            }

            // provides a message when the wrong room is clicked
            else
            {
                MessageBox.Show($"This is not an exit.");
                btnAction.Enabled = false;
                SaveGameState();
            }

        }

        private void btnHint_Click(object sender, EventArgs e)
        {
            // gives the user a hint to which direction to go

            try  // throws an exception when the player clicks button without valid x, y coordinates
            {
                // x and y variables in the textbox to the right 
                int x = Convert.ToInt32(txtX.Text);
                int y = Convert.ToInt32(txtY.Text);

                if (x == 0 && y == 1) // if the user clicks the correct location
                {
                    txtOutput.Text = $"You have found the exit!";
                }

                else // if the user clicks the incorrect location
                {
                    MessageBox.Show($"The north is where you want to be.");
                    btnNorth.ForeColor = Color.Red;
                    Task.Delay(500);
                    btnNorth.ForeColor = Color.Black;
                }
            }

            catch (Exception) //used to catch the exception of the empty txtX and txtY boxes
            {
                MessageBox.Show($"You need to move to get a hint.");
            }

        }


        private void btnRest_Click(object sender, EventArgs e) // click button to reset the game
        {
            // a method that allows the user to reset the game
            // rests the textboxes and buttons
            ResetGame();

        }

        private void ResetGame() // a method reset all of the buttons and textboxes to be clear/empty 
        {
            btnNorth.Enabled = true;
            btnNorth.BackColor = Color.White;
            btnSouth.Enabled = true;
            btnWest.Enabled = true;
            btnEast.Enabled = true;
            btnAction.Enabled = true;
            rdbEast.Enabled = false;
            rdbWest.Enabled = false;
            rdbNorth.Enabled = false;
            rdbSouth.Enabled = false;
            txtX.Text = "0";
            txtY.Text = "0";
            txtX.BackColor = Color.White;
            txtY.BackColor = Color.White;
            txtOutput.Text = $"{startMessage} {endMessage}";
            startTime = DateTime.Now;
            txtSTime.Text = startTime.ToString();
            cboBox.SelectedIndex = 1;
        }


        // Click button to move to the North room using the MoveMovement method
        private void btnNorth_Click(object sender, EventArgs e)
        {
            MoveMovement(Direction.North); // code to move in the north direction
            btnAction.Enabled = true; // enable the action icon

            // code to ensure only the north radion button is active
            rdbNorth.Checked = true;
            rdbSouth.Checked = false;
            rdbWest.Checked = false;
            rdbEast.Checked = false;

        }

        // Click button to move to the South room using the MoveMovement method
        private void btnSouth_Click(object sender, EventArgs e)
        {
            MoveMovement(Direction.South); // code to move in the south direction
            btnAction.Enabled = true; // enable the action icon

            // code to ensure only the south radion button is active
            rdbSouth.Checked = true;
            rdbWest.Checked = false;
            rdbEast.Checked = false;
            rdbNorth.Checked = false;

        }

        // Click button to move to the East room using the MoveMovement method
        private void btnEast_Click(object sender, EventArgs e)
        {
            MoveMovement(Direction.East); // code to move in the east direction
            btnAction.Enabled = true; // enable the action icon

            // code to ensure only the east radion button is active
            rdbSouth.Checked = false;
            rdbWest.Checked = false;
            rdbEast.Checked = true;
            rdbNorth.Checked = false;
        }

        // Click button to move to the West room using the MoveMovement method
        private void btnWest_Click(object sender, EventArgs e)
        {

            MoveMovement(Direction.West); // code to move in the west direction
            btnAction.Enabled = true; // enable the action icon

            // code to ensure only the west radion button is active
            rdbSouth.Checked = false;
            rdbWest.Checked = true;
            rdbEast.Checked = false;
            rdbNorth.Checked = false;
        }

        private void txtOutput2_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtStartTime_TextChanged(object sender, EventArgs e)
        {

        }

        private void rdbNorth_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveGameState();
            MessageBox.Show("Game saved successfully!", "Saved");
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            LoadGameState();
            MessageBox.Show("Game loaded successfully!", "Load");
        }
    }
}