﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Employee___ProductionWorker___ShiftSupervisor
{
    public class Employee
    {
        private string _employeeName;
        private int _employeeNumber;

        public Employee()
        {
            _employeeName = string.Empty;
            _employeeNumber = 0;
        }

        public Employee(string employeeName, int employeeNumber)
        {
            _employeeName = employeeName;
            _employeeNumber = employeeNumber;
        }

        public string EmployeeName
        {
            get { return _employeeName; }
            set { _employeeName = value; }
        }

        public int EmployeeNumber
        {
            get { return _employeeNumber; }
            set {
                if (_employeeNumber == 1 || _employeeNumber == 2)
                {
                    _employeeNumber = value;
                }
                else
                {
                    MessageBox.Show("Invalid Entry.");
                }
                    
                }
        }

        public override string ToString()
        {
            return "Employee Name: " + _employeeName + "\r\n"
                + "Employee Number: " + _employeeNumber + "\r\n";
        }

    }
}
