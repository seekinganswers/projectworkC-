﻿namespace Project_Employee___ProductionWorker___ShiftSupervisor
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            displayButton = new Button();
            outputLabel = new Label();
            clearButton = new Button();
            exitButton = new Button();
            label5 = new Label();
            label6 = new Label();
            checkBox1 = new CheckBox();
            label7 = new Label();
            label8 = new Label();
            annualSalaryTextBox = new TextBox();
            bonusTextBox = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(72, 61);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(135, 24);
            label1.TabIndex = 0;
            label1.Text = "Employee Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(55, 133);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(152, 24);
            label2.TabIndex = 1;
            label2.Text = "Employee Number";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(100, 220);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(111, 24);
            label3.TabIndex = 2;
            label3.Text = "Shift Number";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(112, 302);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(95, 24);
            label4.TabIndex = 3;
            label4.Text = "Hourly Pay";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(346, 44);
            textBox1.Margin = new Padding(4);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(193, 40);
            textBox1.TabIndex = 4;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(346, 116);
            textBox2.Margin = new Padding(4);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(193, 40);
            textBox2.TabIndex = 5;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(346, 203);
            textBox3.Margin = new Padding(4);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(193, 40);
            textBox3.TabIndex = 6;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(346, 286);
            textBox4.Margin = new Padding(4);
            textBox4.Multiline = true;
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(193, 40);
            textBox4.TabIndex = 7;
            // 
            // displayButton
            // 
            displayButton.Location = new Point(241, 680);
            displayButton.Margin = new Padding(4);
            displayButton.Name = "displayButton";
            displayButton.Size = new Size(113, 58);
            displayButton.TabIndex = 8;
            displayButton.Text = "Display";
            displayButton.UseVisualStyleBackColor = true;
            displayButton.Click += displayButton_Click;
            // 
            // outputLabel
            // 
            outputLabel.BorderStyle = BorderStyle.FixedSingle;
            outputLabel.Location = new Point(226, 462);
            outputLabel.Margin = new Padding(4, 0, 4, 0);
            outputLabel.Name = "outputLabel";
            outputLabel.Size = new Size(436, 193);
            outputLabel.TabIndex = 9;
            // 
            // clearButton
            // 
            clearButton.Location = new Point(396, 680);
            clearButton.Margin = new Padding(4);
            clearButton.Name = "clearButton";
            clearButton.Size = new Size(113, 58);
            clearButton.TabIndex = 10;
            clearButton.Text = "Clear";
            clearButton.UseVisualStyleBackColor = true;
            clearButton.Click += clearButton_Click;
            // 
            // exitButton
            // 
            exitButton.Location = new Point(564, 680);
            exitButton.Margin = new Padding(4);
            exitButton.Name = "exitButton";
            exitButton.Size = new Size(113, 58);
            exitButton.TabIndex = 11;
            exitButton.Text = "Exit";
            exitButton.UseVisualStyleBackColor = true;
            exitButton.Click += exitButton_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = SystemColors.ActiveCaption;
            label5.Location = new Point(860, 697);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(101, 24);
            label5.TabIndex = 12;
            label5.Text = "Dorothy Hill";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(108, 375);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(99, 24);
            label6.TabIndex = 13;
            label6.Text = "Supervisor ";
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(226, 375);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(60, 28);
            checkBox1.TabIndex = 14;
            checkBox1.Text = "Yes";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(396, 362);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(219, 24);
            label7.TabIndex = 16;
            label7.Text = "Supervisor's Annual Salary";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(452, 415);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(163, 24);
            label8.TabIndex = 17;
            label8.Text = "Supervisor's Bonus";
            label8.Click += label8_Click;
            // 
            // annualSalaryTextBox
            // 
            annualSalaryTextBox.Location = new Point(697, 346);
            annualSalaryTextBox.Margin = new Padding(4);
            annualSalaryTextBox.Multiline = true;
            annualSalaryTextBox.Name = "annualSalaryTextBox";
            annualSalaryTextBox.Size = new Size(193, 40);
            annualSalaryTextBox.TabIndex = 18;
            // 
            // bonusTextBox
            // 
            bonusTextBox.Location = new Point(697, 397);
            bonusTextBox.Margin = new Padding(4);
            bonusTextBox.Multiline = true;
            bonusTextBox.Name = "bonusTextBox";
            bonusTextBox.Size = new Size(193, 40);
            bonusTextBox.TabIndex = 19;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 24F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1000, 751);
            Controls.Add(bonusTextBox);
            Controls.Add(annualSalaryTextBox);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(checkBox1);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(exitButton);
            Controls.Add(clearButton);
            Controls.Add(outputLabel);
            Controls.Add(displayButton);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Margin = new Padding(4);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private Button displayButton;
        private Label outputLabel;
        private Button clearButton;
        private Button exitButton;
        private Label label5;
        private Label label6;
        private CheckBox checkBox1;
        private Label label7;
        private Label label8;
        private TextBox annualSalaryTextBox;
        private TextBox bonusTextBox;
    }
}
