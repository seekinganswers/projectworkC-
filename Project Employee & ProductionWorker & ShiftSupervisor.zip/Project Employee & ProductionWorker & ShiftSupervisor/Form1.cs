namespace Project_Employee___ProductionWorker___ShiftSupervisor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            textBox1.Text = " ";
            textBox2.Text = " ";
            textBox3.Text = " ";
            textBox4.Text = " ";
            outputLabel.Text = " ";
            annualSalaryTextBox.Text = " ";
            bonusTextBox.Text = " ";
            checkBox1.Checked = false;
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            string EmployeeName = textBox1.Text;
            int EmployeeNumber = Convert.ToInt32(textBox2.Text);
            int shiftNumber = Convert.ToInt32(textBox3.Text);
            decimal hourlyPay;
            bool isValidPay = decimal.TryParse(textBox4.Text, out hourlyPay);
            int annualSalary;
            bool isValidAnnualSalary = int.TryParse(annualSalaryTextBox.Text, out annualSalary);
            int bonus;
            bool isValidBonus= int.TryParse(bonusTextBox.Text, out bonus);

            if(isValidAnnualSalary == false || isValidBonus == false || annualSalary == 0 || bonus == 0)
            {
                ProductionWorker worker = new ProductionWorker(EmployeeName, EmployeeNumber, shiftNumber, hourlyPay);
                outputLabel.Text = worker.ToString();
            }
            
            if(checkBox1.Checked && isValidPay == false || hourlyPay == 0)
            {
                ShiftSupervisor worker2 = new ShiftSupervisor(EmployeeName, EmployeeNumber, annualSalary, bonus);
                outputLabel.Text = worker2.ToString();
            }
            
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
    }
}
