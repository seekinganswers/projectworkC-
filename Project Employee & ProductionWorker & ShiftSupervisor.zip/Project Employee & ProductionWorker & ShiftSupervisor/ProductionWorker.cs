﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Employee___ProductionWorker___ShiftSupervisor
{
    public class ProductionWorker : Employee
    {
        public ProductionWorker(string EmployeeName, int EmployeeNumber, int shiftNumber, decimal hourlyPay) : base(EmployeeName, EmployeeNumber)
        {
            ShiftNumber = shiftNumber;
            HourlyPay = hourlyPay;
        }
        public int ShiftNumber {get; set;}
        public decimal HourlyPay { get; set;}

        public override string ToString()
        {
            return base.ToString() + "Worker Shift: " + ShiftNumber + "\r\n" +
                "Worker Hourly Pay: " + HourlyPay + "\r\n";
        }
    }
}
