﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Employee___ProductionWorker___ShiftSupervisor
{
    public class ShiftSupervisor : Employee
    {
        public ShiftSupervisor(string EmployeeName, int EmployeeNumber, int annualSalary, int bonus) : base(EmployeeName, EmployeeNumber)
        {
            AnnualSalary = annualSalary;
            Bonus = bonus;
        }
        public int AnnualSalary { get; set; }
        public int Bonus { get; set;}

        public override string ToString()
        {
            return base.ToString() + "Annual Salary: " + AnnualSalary + "\r\n" +
                "Bonus : " + Bonus + "\r\n";
        }
    }
}
